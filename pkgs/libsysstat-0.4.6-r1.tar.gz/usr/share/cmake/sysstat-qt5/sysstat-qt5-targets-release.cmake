#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "sysstat-qt5" for configuration "Release"
set_property(TARGET sysstat-qt5 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(sysstat-qt5 PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsysstat-qt5.so.0.4.6"
  IMPORTED_SONAME_RELEASE "libsysstat-qt5.so.0"
  )

list(APPEND _cmake_import_check_targets sysstat-qt5 )
list(APPEND _cmake_import_check_files_for_sysstat-qt5 "${_IMPORT_PREFIX}/lib/libsysstat-qt5.so.0.4.6" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
