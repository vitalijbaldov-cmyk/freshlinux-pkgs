#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fm-qt" for configuration "Release"
set_property(TARGET fm-qt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fm-qt PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libfm-qt.so.14.0.0"
  IMPORTED_SONAME_RELEASE "libfm-qt.so.14"
  )

list(APPEND _cmake_import_check_targets fm-qt )
list(APPEND _cmake_import_check_files_for_fm-qt "${_IMPORT_PREFIX}/lib/libfm-qt.so.14.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
